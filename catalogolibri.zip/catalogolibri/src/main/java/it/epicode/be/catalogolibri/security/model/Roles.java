package it.epicode.be.catalogolibri.security.model;

public enum Roles {
	
	ROLE_USER, ROLE_ADMIN

}
