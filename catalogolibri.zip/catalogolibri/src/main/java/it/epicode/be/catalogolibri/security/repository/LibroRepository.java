package it.epicode.be.catalogolibri.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import it.epicode.be.catalogolibri.security.model.Autore;
import it.epicode.be.catalogolibri.security.model.Categoria;
import it.epicode.be.catalogolibri.security.model.Libro;


public interface LibroRepository extends JpaRepository<Libro, Long>{
	List<Libro> findByTitolo(String titolo);
	List<Libro> findByAutoriCognome(String cognome);
	List<Libro> findByCategorieNome(String categoria);
}
