package it.epicode.be.catalogolibri.security.util;

import java.util.HashSet;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import it.epicode.be.catalogolibri.security.model.Role;
import it.epicode.be.catalogolibri.security.model.Roles;
import it.epicode.be.catalogolibri.security.model.User;
import it.epicode.be.catalogolibri.security.repository.RoleRepository;
import it.epicode.be.catalogolibri.security.repository.UserRepository;


@Component
public class AddUserSpringRunner implements CommandLineRunner {

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleRepository roleRepository;

	@Override
	public void run(String... args) throws Exception {
		BCryptPasswordEncoder bCrypt = new BCryptPasswordEncoder();
		
		/*Role roleU = new Role();
		roleU.setRoleName(Roles.ROLE_USER);
		Role role = new Role();
		role.setRoleName(Roles.ROLE_ADMIN);
		User user = new User();
		Set<Role> roles = new HashSet<>(); 
		roles.add(role);
		user.setUserName("admin");
		user.setPassword(bCrypt.encode("admin"));
		user.setEmail("admin@domain.com");
		user.setRoles(roles);
		user.setActive(true);
		
		roleRepository.save(roleU);
		roleRepository.save(role);
		userRepository.save(user);*/
		
		Role roleA = new Role();
		roleA.setRoleName(Roles.ROLE_ADMIN);
		roleRepository.save(roleA);
		
		Role roleU = new Role();
		roleU.setRoleName(Roles.ROLE_USER);
		roleRepository.save(roleU); 

		User userA = new User();
		userA.setUserName("admin");
		userA.setPassword(bCrypt.encode("admin"));
		userA.setEmail("admin@domain.com");
		userA.setActive(true);
		Set<Role> rolesA = new HashSet<>();
		rolesA.add(roleA);
		rolesA.add(roleU);
		userA.setRoles(rolesA);
		userRepository.save(userA);
		
		User userU = new User();
		userU.setUserName("user");
		userU.setPassword(bCrypt.encode("user"));
		userU.setEmail("user@domain.com");
		userU.setActive(true);
		Set<Role> rolesU = new HashSet<>();
		rolesU.add(roleU);
		userU.setRoles(rolesU);
		userRepository.save(userU);
		
	}

}
