package it.epicode.be.catalogolibri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogolibriApplicationTests {

	@Test
	void contextLoads() {
	}

}
